﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineExam.Controllers
{
    public class StudentExamController : Controller
    {
        // GET: StudentExam
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Exam()
        {
            return View();
        }
    }
}