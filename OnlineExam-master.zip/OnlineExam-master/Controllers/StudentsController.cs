﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OnlineExam.Models;

namespace OnlineExam.Controllers
{
    public class StudentsController : Controller
    {
        private DBModel db = new DBModel();

        // GET: Students
        public ActionResult Index()
        {
            var students = db.Students.Include(s => s.Batch).Include(s => s.User);
            return View(students.ToList());
        }

        // GET: Students/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            StudentVM studentVM = new StudentVM();

            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // GET: Students/Create
        public ActionResult Create()
        {
            Batch batch = db.Batches.Where(Row=>Row.ID>0).ToList().First();
            ViewBag.Batch = db.Batches.ToList(); 
            return View(new StudentVM());
        }

        // POST: Students/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(StudentVM model)
        {
            if (ModelState.IsValid)
            {
                

                
                model.user.Type = 3;//Student type=3
                db.Users.Add(model.user);
                db.SaveChanges();
                var LastUserId = db.Users.AsEnumerable().LastOrDefault().ID;
                model.student.UserID = LastUserId;
                model.student.Image= saveImage(model.ImageToUpload, model.student);//take image and rename it then save it
                db.Students.Add(model.student);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return RedirectToAction("Create");
        }
        string saveImage(HttpPostedFileBase Image , Student student)
        {
            try { System.IO.File.Delete(Server.MapPath("~") + student.Image); } catch { };
            string path = Path.Combine(Server.MapPath("~/UploadedImages"), Path.GetFileName(Image.FileName));
            Image.SaveAs(path);
            string NewPath = "\\Img" + student.UserID + path.Substring(path.LastIndexOf("."));
            System.IO.File.Move(path, Server.MapPath("~/UploadedImages") + NewPath);
            return("UploadedImages" + NewPath);
        }

        // GET: Students/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
           


            Student student = db.Students.Find(id);
            StudentVM studentVM = new StudentVM();
            studentVM.user = student.User;
            studentVM.student = student;
            
            if (student == null)
            {
                return HttpNotFound();
            }
            ViewBag.Batch = db.Batches.ToList();
            return View(studentVM);
        }

        // POST: Students/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(StudentVM model)
        {
            if (ModelState.IsValid)
            {
                model.student.Image = saveImage(model.ImageToUpload, model.student);//take image and rename it then save it
                db.Entry(model.user).State = EntityState.Modified;
                db.Entry(model.student).State = EntityState.Modified;

                db.SaveChanges();
                
                return RedirectToAction("Index");
            }

            return View(model);
        }

        // GET: Students/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = db.Users.Find(id);
            user.Active = false;
            db.SaveChanges();
            if (user == null)
            {
                return HttpNotFound();
            }
            return RedirectToAction("Index");
        }

        // POST: Students/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Student student = db.Students.Find(id);
            db.Students.Remove(student);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
